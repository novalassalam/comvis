# Face Recognition

face recognition using python and mysql

## Instalation

1. create a database facerecognition
2. import facerecognition.sql
3. run train.py
   will add a new file in the form of train.yml
4. run faces.

## make sure the webcam is active

