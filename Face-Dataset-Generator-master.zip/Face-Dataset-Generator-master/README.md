# Face-Dataset-Generator
 generte face dataset using Python & OpenCV
 
 
## On Capture
![](https://raw.githubusercontent.com/Muhammad-Yunus/Face-Dataset-Generator/master/resource/capture.PNG)

## Result image
![](https://raw.githubusercontent.com/Muhammad-Yunus/Face-Dataset-Generator/master/resource/result.PNG)
